#!/bin/bash
rm -Rf /var/www/html/*
mkdir -p /var/www/html
